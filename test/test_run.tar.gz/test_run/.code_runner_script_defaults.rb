# coding: utf-8
{:code=>"gs2",
 :code_runner_version=>"0.14.23.0",
 :modlet=>nil,
 :executable=>"/home/vanwyk/code/gs2/trunk/gs2",
 :defaults_file=>"test_gs2_correlation",
 :project=>nil}
