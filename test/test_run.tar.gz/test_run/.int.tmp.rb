{:v=>"", :G=>[], :g=>[], :k=>true, :h=>:real, :p=>[], :U=>true, :u=>true, :F=>{}}.each do |key, val|
					CodeRunner::DEFAULT_COMMAND_OPTIONS[key] = val
				end


include CodeRunner::InteractiveMethods
setup_interactive
module Kernel

		alias_method(:shell_do, "`".to_sym)
	def `(cmd)
		c =caller
		if c[0] =~ /irb_binding/
			system(cmd)
		else
			shell_do(cmd)
		end
	end
end
