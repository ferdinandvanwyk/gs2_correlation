# <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
# GS2 Gyrokinetic Flux Tube Code Input Parameters
# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
# Code: 		gs2
# System: 	generic_linux
# Version:	
# Nprocs: 	4
# Directory:	/home/vanwyk/work/gs2/cbc/nonlinear/test_run/v/id_1
# Runname:	v_id_1
# ID:		1
#  
# Classname:	CodeRunner::Gs2

# Job_No:		-1

# Parameters:
{:beta=>0.0,
 :zeff=>1.0,
 :grid_option=>"box",
 :nx=>8,
 :ny=>12,
 :jtwist=>4,
 :y0=>10.0,
 :x0=>10.0,
 :ntheta=>8,
 :nperiod=>1,
 :eps=>0.18,
 :epsl=>2.0,
 :shat=>0.8,
 :pk=>1.44,
 :shift=>0.0,
 :equilibrium_option=>"s-alpha",
 :model_option=>"default",
 :ngauss=>5,
 :negrid=>8,
 :gridfac=>1.0,
 :omprimfac=>1.0,
 :boundary_option=>"linked",
 :adiabatic_option=>"iphi00=2",
 :g_exb=>0.0,
 :nonad_zero=>".true.",
 :field_option=>"local",
 :wstar_units=>".false.",
 :fphi=>1.0,
 :fapar=>0.0,
 :faperp=>0.0,
 :delt=>0.01,
 :nstep=>50,
 :avail_cpu_time=>600,
 :delt_adj=>2.0,
 :delt_minimum=>1.0e-06,
 :layout=>"xyles",
 :collision_model=>"default",
 :nonlinear_mode=>"on",
 :flow_mode=>"off",
 :cfl=>0.5,
 :nspec=>1,
 :z_1=>1.0,
 :mass_1=>1.0,
 :dens_1=>1.0,
 :temp_1=>1.0,
 :tprim_1=>6.9,
 :fprim_1=>2.2,
 :uprim_1=>0.0,
 :vnewk_1=>0.01,
 :type_1=>"ion",
 :fexpr_1=>0.45,
 :bakdif_1=>0.05,
 :chop_side=>".false.",
 :phiinit=>0.001,
 :restart_file=>"gs2.nc",
 :ginit_option=>"noise",
 :restart_dir=>"nc",
 :print_flux_line=>".false.",
 :write_nl_flux=>".true.",
 :print_line=>".false.",
 :write_verr=>".true.",
 :write_line=>".true.",
 :write_hrate=>".false.",
 :write_avg_moments=>".F.",
 :write_omega=>".false.",
 :write_omavg=>".false.",
 :write_eigenfunc=>".true.",
 :write_final_fields=>".true.",
 :write_final_moments=>".true.",
 :nsave=>500,
 :nwrite=>1,
 :navg=>10,
 :omegatol=>-0.001,
 :omegatinst=>500.0,
 :save_for_restart=>".false.",
 :write_phi_over_time=>".true.",
 :write_moments=>".true.",
 :nwrite_new=>1,
 :job_no=>-1,
 :id=>1,
 :sys=>"generic_linux",
 :naming_pars=>[],
 :run_name=>"v_id_1",
 :parameter_hash=>{},
 :parameter_hash_string=>"{}",
 :output_file=>"gs2.1.o",
 :error_file=>"gs2.1.e",
 :nprocs=>"4",
 :wall_mins=>10,
 :executable=>"/home/vanwyk/code/gs2/trunk/gs2",
 :code=>"gs2"}



# Actual Command:
# time mpirun -np 4 /home/vanwyk/code/gs2/trunk/gs2 v_id_1.in > gs2.1.o 2> gs2.1.e
# <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
